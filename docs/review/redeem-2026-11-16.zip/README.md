# Redeem verification artifact

Backend commit: `3f1629dadc78111176886b716db425ef9c9dcb9e`
Contract revision: `1dc42d555046830c7320e46052696f62ab380dad`

Automated checks: **PASS**.
AC3 wallet mapping remains pending.
Scope: approved local chain. FEAT-11 T8 is separate schema work in #213.

| Stage | Result | Tests |
|---|---|---|
| standard | PASS | {'tests': 226, 'failures': 0, 'errors': 0, 'skipped': 0, 'passed': 226} |
| postgres | PASS | {'tests': 65, 'failures': 0, 'errors': 0, 'skipped': 0, 'passed': 65} |
| local-chain | PASS | {'tests': 21, 'failures': 0, 'errors': 0, 'skipped': 0, 'passed': 21} |

| AC | Evidence |
|---|---|
| 1, 15 | standard.junit.xml; schema, API and artifact validation |
| 2 | postgres.junit.xml; signed-JWT rejection tests |
| 3 | PENDING, not claimed complete |
| 4–8 | postgres.junit.xml; actual SQL admission, replay, concurrency and rollback |
| 9–13 | local-chain.junit.xml; handler/projector with pinned EVM and PostgreSQL |
| 14 | Recorded mapping in docs/redeem-state.md and #213. Legacy SQL not rerun. |

Each stage has its command and exit code in manifest.json, JUnit results, and a text log.
source-sha256.json identifies the tested source files. No environment dump is included.
The standard stage excludes chain cases; the local-chain stage runs them separately.
API/Postman files are copies of committed review assets. Their mock values are fixtures.
Verify extracted files with: `shasum -a 256 -c SHA256SUMS`.
